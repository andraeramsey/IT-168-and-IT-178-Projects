package edu.ilstu;

public class UseDinnerPArtyWithConstructor
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		DinnerPartyWithConstructor aDinnerParty= new DinnerPartyWithConstructor();
	}

}
