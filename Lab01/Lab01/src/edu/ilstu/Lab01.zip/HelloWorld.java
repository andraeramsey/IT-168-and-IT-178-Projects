/*
 * File nam: HelloWorld.java
 * Programmer: Andrae Ramsey
 * ULID: arrams1
 * Date: Aug 20, 2015
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Schaefer
 * Lab Section: 21
 * Lab Instructor: Kora
 */
package edu.ilstu;

/**
 * <This is the traditional first program for people to run when attempting to learn a new programming language.>
 * @author Andrae Ramsey
 *
 */
public class HelloWorld
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{
		System.out.println("Hello World!");

	}

}
