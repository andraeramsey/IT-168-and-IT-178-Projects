/*
 * File name: VacationHomeOutput.java
 * Programmer: Andrae Ramsey
 * ULID: arrams1
 * Date: Oct 3, 2015
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Schaefer
 * Lab Section: 21
 * Lab Instructor: Kora
 */
package edu.ilstu.it168.program3.arrams1;

/**
 * <shows what is output to the screen>
 * @author Andrae Ramsey
 *
 */
public class VacationHomeOutput
{
	/**
	 * displays greeting
	 */
	public  void displayGreeting()
	{		
		System.out.println("Welcome to Holiday Resort Vacation Home Rentals\n");
	}
	/**
	 * displays receipt
	 * @param seasonalRate
	 * @param determineDiscount
	 * @param RETURNABLE_DEPOSIT
	 * @param total
	 */
	public void displayReceipt(VacationHomeRental rentalOrder,double seasonalRate,double determineDiscount,int RETURNABLE_DEPOSIT,double total)
	{
		System.out.printf("Rental cost:\t$\t"+"%5.2",seasonalRate+"\n"+"%5.2",determineDiscount+"Deposit:\t"+"%5.2",RETURNABLE_DEPOSIT+"\n\n"+"Total:\t"+"%5.2",total);
	}
	/**
	 * displays customer info
	 * @param formatLabel
	 */
	public void displayCustomer(Customer customer,String formatLabel)
	{
		System.out.print(formatLabel);
	}
	/**
	 * displays goodbye statement
	 * @param formatLabel
	 */
	public void displayGoodbye(String formatLabel)
	{
		System.out.print("\nThank you for renting from us.\n");
		//store info using formatLabel(?) (& return Business info?)
	}	
	public VacationHomeOutput(){}
}

