/*
 * File name: Customer.java
 * Programmer: Andrae Ramsey
 * ULID: arrams1
 * Date: Oct 3, 2015
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Schaefer
 * Lab Section: 21
 * Lab Instructor: Kora
 */
package edu.ilstu.it168.program3.arrams1;

/**
 * <a class that stores customer info>
 * @author Andrae Ramsey
 *
 */
public class Customer
{
	private String firstName;
	private String lastName;
	private String address;
	private String city;
	private String state;
	private String zipCode;
	private String phoneNumber;
	
	
	/**
	 * Customer constructor with no arguments
	 */
	public Customer(){}
	/**
	 * Customer constructor with all parameters passed
	 * @param firstName
	 * @param lastName
	 * @param address
	 * @param city
	 * @param state
	 * @param zipCode
	 * @param phoneNumber
	 */
	public Customer(String firstName,String lastName,String address,String city,String state,String zipCode,String phoneNumber){}
	
	/**
	 *  format label constructor
	 * @param firstName
	 * @param lastName
	 * @param address
	 * @param city
	 * @param state
	 * @param zipCode
	 * @param phoneNumber
	 * @return
	 */
	public String formatLabel(String firstName,String lastName,String address,String city,String state,String zipCode,String phoneNumber)
	{	
		if(firstName==null)
			System.out.print("Holiday Resort Vacation Home Rentals\n 239 E. Hwy 98\nCocoa Beach, FL  32540 \n (850)729-1000");
		return String.format(firstName+"\t"+lastName+"\n"+address+city+",\t"+state+"\t"+zipCode+"\n"+phoneNumber);
	}
	//fix return
	/**
	 * formater for phone number
	 * @param phoneNumber
	 * @return phoneNumber
	 */
	public String formatPhone(String phoneNumber)
	{
		return String.format("%(s)%s-%s", phoneNumber.substring(0, 3), phoneNumber.substring(3, 6), phoneNumber.substring(6, 10));
		//http://stackoverflow.com/questions/5114762/how-do-format-a-phone-number-as-a-string-in-java
	}
	
	
	//Getters and Setters
	
	/**
	 * setter for first name
	 * @param firstName
	 */
	public void setFirstName(String firstName)
	{}
	/**
	 * getter for first name
	 * @return firstName
	 */
	public String getFirstName()
	{
		return firstName;
	}
	/**
	 * setter for last name
	 * @param lastName
	 */
	public void setLastName(String lastName)
	{}
	/**
	 * getter for last name
	 * @return lastName
	 */
	public String getLastName()
	{
		return lastName;
	}
	/**
	 * setter for address
	 * @param address
	 */
	public void setaddress(String address)
	{}
	/**
	 * getter for address
	 * @return address
	 */
	public String getaddress()
	{
		return address;
	}
	/**
	 * setter for city
	 * @param city
	 */
	public void setCity(String city)
	{}
	/**
	 * getter for city
	 * @return city
	 */
	public String getCity()
	{
		return city;
	}
	/**
	 * setter for state
	 * @param state
	 */
	public void setState(String state)
	{}
	/**
	 * getter for state
	 * @return state
	 */
	public String getState()
	{
		return state;
	}
	/**
	 * setter for zip code
	 * @param zipCode
	 */
	public void setZipCode(String zipCode)
	{}
	/**
	 * getter for zip code
	 * @return zipCode
	 */
	public String getZipCode()
	{
		return zipCode;
	}
	/**
	 * setter for phone number
	 * @param phoneNumber
	 */
	public void setPhoneNumber(String phoneNumber)
	{}
	/**
	 * getter for phone number
	 * @return phoneNumber
	 */
	public String getPhoneNumber()
	{
		return phoneNumber;
	}
	
	
}
