/*
 * File name: VacationHomeOutput.java
 * Programmer: Andrae Ramsey
 * ULID: arrams1
 * Date: Oct 3, 2015
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Schaefer
 * Lab Section: 21
 * Lab Instructor: Kora
 */
package edu.ilstu.it168.program3.arrams1;

/**
 * <insert class description here>
 * @author Andrae Ramsey
 *
 */
public class VacationHomeOutput
{
	public void displayGreeting()
	{
		System.out.println("Welcome to Holiday Resort Vacation Home Rentals\n");
	}	
	public void displayReceipt(double seasonalRate,double determineDiscount,int RETURNABLE_DEPOSIT,double total)
	{
		//cost of rental,discount(if applicable),deposit,total
	}	
	public void displayCustomer(String formatLabel)
	{
		System.out.print(formatLabel);
	}
	public void displayGoodbye(String formatLabel)
	{
		System.out.print("\nThank you for renting from us.\n");
		//store info using formatLabel(?) (& return Business info?)
	}
}
