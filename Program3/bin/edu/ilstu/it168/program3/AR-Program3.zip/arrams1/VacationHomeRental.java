/*
 * File name: VacationHomeRental.java
 * Programmer: Andrae Ramsey
 * ULID: arrams1
 * Date: Oct 3, 2015
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Schaefer
 * Lab Section: 21
 * Lab Instructor: Kora
 */
package edu.ilstu.it168.program3.arrams1;

/**
 * <A class that holds number calculations>
 * @author Andrae Ramsey
 *
 */
public class VacationHomeRental
{
	//Constants
		private final double DISCOUNT=0.15;
		private final int RETURNABLE_DEPOSIT=250;		
		
		private final double SPRING=200.00;
		private final double SUMMER=300.00;
		private final double FALL=250.00;
		private final double WINTER=100.00;
				
		
	//Instance Variables
		private int daysRented=0;
		private int homesRented=0;
		private int rentalDate;
		private double discount=0;
		
		double seasonalRate=0;
		
	//Methods
		public double calculateTotal()
		{
			double total=((daysRented*seasonalRate)-DISCOUNT+RETURNABLE_DEPOSIT)*homesRented;
			return total;
		}
		public double calculateVacationHomeCost()
		{
			double costOfHome=(daysRented*seasonalRate)*homesRented;
			return costOfHome;
		}
		public double calculateDiscount(double costOfHome)
		{
			double discount=DISCOUNT*costOfHome;
			return discount;
		}
		public void determinePrice()
		{
			if ((rentalDate>=03/01/2015)&&(rentalDate<=05/31/2015))
				seasonalRate=SPRING;
			else if ((rentalDate>=06/01/2015)&&(rentalDate<=08/31/2015))
				seasonalRate=SUMMER;
			else if ((rentalDate>=09/01/2015)&&(rentalDate<=11/30/2015))
				seasonalRate=FALL;
			else if ((rentalDate>=12/01/2015)&&(rentalDate<=02/29/2016))
				seasonalRate=WINTER;
			else if ((rentalDate<03/01/2015)||(rentalDate>12/31/2016))
				System.out.print("Invalid Date");
		}
		public void determineDiscount(double DISCOUNT, double discount)
		{
			if (daysRented<7)
				discount=0;
			else
				discount=discount;
		}
		public void setDaysRented(int daysRented)
		{}
		public int getDaysRented()
		{
			return daysRented;
		}
		public void setHomesRented(int homesRented)
		{}
		public int getHomesRented()
		{
			return homesRented;
		}
		public void setRentalDate(int rentalDate)
		{}
		public int getRentalDate()
		{
			return rentalDate;
		}
}
//format date,fix determine discount,seasonalRate=season