/*
 * File name: Customer.java
 * Programmer: Andrae Ramsey
 * ULID: arrams1
 * Date: Oct 3, 2015
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Schaefer
 * Lab Section: 21
 * Lab Instructor: Kora
 */
package edu.ilstu.it168.program3.arrams1;

/**
 * <a class that stores customer info>
 * @author Andrae Ramsey
 *
 */
public class Customer
{
	private String firstName;
	private String lastName;
	private String adress;
	private String city;
	private String state;
	private String zipCode;
	private String phoneNumber;
	
	//pass the instance var and use this. for setters
	
	public Customer(){}
	public Customer(String firstName,String lastName,String adress,String city,String state,String zipCode,String phoneNumber)
	{
		return;
	}
	//fix return
	public String formatLabel(String firstName,String lastName,String adress,String city,String state,String zipCode,String phoneNumber)
	{
		return;
	}
	//fix return
	public void formatPhone(String phoneNumber)
	{
		System.out.printf("");
	}
	
	//Getters and Setters
	
	public void setFirstName(String firstName)
	{}
	public String getFirstName()
	{
		return firstName;
	}
	
	public void setLastName(String lastName)
	{}
	public String getLastName()
	{
		return lastName;
	}
	
	public void setAdress(String adress)
	{}
	public String getAdress()
	{
		return adress;
	}
	
	public void setCity(String city)
	{}
	public String getCity()
	{
		return city;
	}
	
	public void setState(String state)
	{}
	public String getState()
	{
		return state;
	}
	
	public void setZipCode(String zipCode)
	{}
	public String getZipCode()
	{
		return zipCode;
	}
	
	public void setPhoneNumber(String phoneNumber)
	{}
	public String getPhoneNumber()
	{
		return phoneNumber;
	}
	
	
}
