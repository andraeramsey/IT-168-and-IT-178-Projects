/*
 * File name: VacationHomeInput.java
 * Programmer: Andrae Ramsey
 * ULID: arrams1
 * Date: Oct 3, 2015
 *
 * Class: IT 168
 * Lecture Section: 19
 * Lecture Instructor: Schaefer
 * Lab Section: 21
 * Lab Instructor: Kora
 */
package edu.ilstu.it168.program3.arrams1;

import java.util.Scanner;

/**
 * <insert class description here>
 * @author Andrae Ramsey
 *
 */
public class VacationHomeInput
{
	Scanner keyboard= new Scanner(System.in);
	
	public void readRentalOrder()
	{
		
		System.out.println("Enter number of rental homes:\t");
		//homesRented=keyboard.nextInt()
		System.out.println("Enter number of days:\t"+"\n");
		//daysRented=keyboard.nextInt()
	}
	public void readCustomer()
	{
		System.out.println("Please enter customer information:"); 
		Customer customer=new Customer();
		System.out.println("Enter first name:\t");
		String firstName=keyboard.toString();
		customer.setFirstName(firstName);
		
		System.out.println("Enter last name:\t");
		String lastName=keyboard.toString();
		customer.setLastName(lastName);
		
		System.out.println("Enter street adress:\t");
		String adress=keyboard.toString();
		customer.setAdress(adress);
		
		System.out.println("Enter city:\t");
		String city=keyboard.toString();
		customer.setCity(city);
		
		System.out.println("Enter state:\t");
		String state=keyboard.toString();
		customer.setState(state);
		
		System.out.println("Enter zip code:\t");
		String zipCode=keyboard.toString();
		customer.setZipCode(zipCode);
		
		System.out.println("Enter phone number in form 9999999999:\t");
		String phoneNumber=keyboard.toString();
		customer.setPhoneNumber(phoneNumber);
		
		System.out.println("Enter start date in form mm/dd/yyyy:\t");
		String rentalDate=keyboard.toString();
		customer.setRentalDate(rentalDate);
	}

}
